#!/bin/bash

pkill monitor;
pkill forwarder;
pkill router;

# CU should be killed where it was launched
#pkill CU;
