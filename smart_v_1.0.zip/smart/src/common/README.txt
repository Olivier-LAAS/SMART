This folder contains all common functions and declarations
Eigen is an external library used in src/router/RNN.h,cpp. This library is ti be included as simple header files that will be compiled with code.
When generating documentation, Eigen should not be included otherwise doxygen will stop on fault.
